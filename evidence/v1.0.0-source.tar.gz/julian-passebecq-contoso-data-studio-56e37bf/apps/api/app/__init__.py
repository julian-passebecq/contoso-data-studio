"""Contoso Data Studio API."""
